---
title: "4-Bed Spacious House — Askari V"
slug: "4-bed-spacious-house-askari-v"
status: "Available"
category: "Sale"
price: 14500000
currency: "PKR"
location: "Askari V"
address: "Askari V, Karachi"
bedrooms: 4
bathrooms: 3
size: "2000"
images: ['/assets/BhattiEstate.png']
map_embed: ""
features: ['Large garden', 'Driveway', 'Close to bazaars']
published: true
date: "2025-10-02"
---

A spacious family house with a garden and modern finishes in Askari V.

---
title: "2-Bed Apartment — Askari IV"
slug: "2-bed-apartment-askari-iv"
status: "Available"
category: "Sale"
price: 6500000
currency: "PKR"
location: "Askari IV"
address: "Askari IV, Karachi"
bedrooms: 2
bathrooms: 2
size: "850"
images: ['/assets/BhattiEstate.png']
map_embed: ""
features: ['Gated community', 'Nearby school', 'Easy access to main road']
published: true
date: "2025-10-02"
---

Comfortable 2-bedroom apartment in Askari IV, perfect for small families or professionals.
